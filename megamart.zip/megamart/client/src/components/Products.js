import React, { useEffect, useState } from "react";

function Products(){
    const [products, setProducts] = useState([]);
    const [cart, setCart] = useState([]);
    const [selectedOption, setSelectedOption] = useState("");
    const [searchText, setSearchText] = useState("");
    const [showCart, setShowCart] = useState(false);

    useEffect(()=>{
        fetchProducts();
    }, []);
    const fetchProducts = async () => {
        try{
            const response = await fetch('https://fakestoreapi.com/products');
            const data = await response.json();
            setProducts(data);
            console.log(products);
        }
        catch(error){
            console.error('Error fetching products:', error);
        }
    };
    const handleOptionChange = (e) => {
        setSelectedOption(e.target.value);
        setShowCart(false);
    }
    const filteredProducts = products.filter((product) =>
        selectedOption ===  "" || product.category === selectedOption
    );
    const handleChange = ()=>{
        const productsFiltered = products.filter((product) =>{
        searchText ===  "" || product.title.toString().toLowerCase() === searchText.toString().toLowerCase() || product.category.toString().toLowerCase() == searchText.toString().toLowerCase();
        } 
    )
    setProducts(productsFiltered);
    }
    const addToCart = (product) =>{
        setCart([...cart, product]);
    }
    const removeFromCart = (id) =>{
        setCart(cart.filter((product)=> product.id !== id))
    }
    const handCartChange =()=>{
        if (showCart){
            setShowCart(false);
        }
        else{
            setShowCart(true)
        }
    }
    function Rating({value}){
        const stars = []
        for (let i = 1; i <= 5; i++){
            if (i <= value){
                stars.push(<i className="fa fa-star" ></i>)
            }
            else{
                stars.push(<i className="fa fa-star-o" ></i>)
            }
        }
        return <div className="ratings">{stars}</div>
    }
    return(
        <div>
            <div className="container">
            <div className="row d-flex align-items-center" style={{marginTop:'21px'}}>
                <div className="col-lg-4 col-md-4 col-sm-6 col-12 d-flex align-items-center"><div style={{height:'48px', width:'48px', borderRadius:'10px', backgroundColor:'#f7f7f7'}}><h1  style={{ color:'#008ECC', textAlign:'center', fontWeight:'700', lineHeight:'43.57px', fontSize:'36px'}}>M</h1></div><h1 style={{color:'#008ECC', paddingLeft:'16px', fontSize:'30px'}}>MegaMart</h1></div>
                <form className="col-lg-4 col-md-4 col-sm-6 col-12 d-flex align-items-center" id="selectOption" onChange={handleOptionChange} value={selectedOption} >
                   <select style={{width:'30%'}}>
                        <option value="">All</option>
                        <option value="electronics">Electronics</option>
                        <option value="women's clothing">Women's Clothing</option>
                        <option value="men's clothing">Men's Clothing</option>
                        <option value="jewelery">Jewelery</option>

                    </select>
                    <input placeholder="Search here..." style={{width:'170%', paddingLeft:'10px'}} type="text"  value={searchText} onChange={(e)=> setSearchText(e.target.value)} />
                    <div onClick={handleChange}><i className="fa fa-search"></i></div>
                    
                </form>
                <div className="col-lg-3 col-md-4 col-sm-6 col-12 d-flex align-items-center" style={{height:'24px', width:'97px', marginLeft:'200px'}} onClick={handCartChange}>
                    <div onClick={handCartChange} className="d-flex align-items-center">
                <div><i style={{height:'18.1px', width:'18.5px'}} className="fa fa-shopping-cart"></i></div>
                <div style={{height:'18px', width:'35px'}}><h2 style={{fontSize:'16px', lineHeight:'18px'}}>Cart</h2 ></div>
                {cart.length?<div style={{height:'48px', width:'48px', borderRadius:'50%', backgroundColor:'#008ECC', height:'20px', width:'20px'}}><h1  style={{ color:'white', textAlign:'center', fontWeight:'700', lineHeight:'20px', fontSize:'10px'}}>{cart.length}</h1></div>:<h1></h1>}
                </div>
                </div>
            </div>
        </div>
        <div style={{backgroundColor:'#F5F5F5'}}><h1 style={{color:'#008ECC', paddingLeft:'16px', fontSize:'40px', marginLeft:'135px', marginTop:'15px'}}>Results</h1>
        <div className="container" >
            <div className="row">
            {showCart? 
                cart.map((product) =>(
                <div className="col-lg-2 col-md-3 col-sm-6 col-12 m-3" style={{backgroundColor:'white', borderRadius: '15px'}}>
                        <div style={{height:'300px'}}>
                        <img src={product.image} alt={product.title} style={{height:'200px', width:'200px'}}/>
                        <p>{product.title}</p>
                        </div>
                        <div style={{height:'150px'}}>
                        <p>${product.price}</p>
                        <div style={{display:'flex', justifyContent:'center'}}>
                        <button className="btn-danger" onClick={()=>{removeFromCart(product.id)}} style={{marginTop: '20px', padding:'10px', borderRadius:'10px'}}>Remove from Cart</button>
                        </div>
                        </div>
                    </div>
                )):
                filteredProducts.map((product) =>(
                <div className="col-lg-2 col-md-3 col-sm-6 col-12 m-3" style={{ backgroundColor:'white', borderRadius: '15px'}}>
                        <div style={{height:'300px'}}>
                        <img src={product.image} alt={product.title} style={{height:'200px', width:'200px'}}/>
                        <p style={{fontSize:'17px'}}>{product.title}</p>
                        </div>
                        <div style={{height:'150px'}}>
                        <p style={{fontSize:'20px', fontWeight:'bolder'}}>${product.price}</p>
                        <Rating value={product.rating.rate} />
                        <div style={{display:'flex', justifyContent:'center'}}>
                        <button className="btn-success" onClick={()=>{addToCart(product)}} style={{marginTop: '20px', padding:'10px', borderRadius:'10px'}}>Add to Cart</button>
                        </div>
                        </div>
                    </div>
                ))
            }
            </div>
        </div>
        </div>
        </div>
    )
}
export default Products;