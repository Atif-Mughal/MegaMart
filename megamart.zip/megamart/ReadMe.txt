 

---------------------------------------------------------------------------Instruction Guide---------------------------------------------------------------------

1. Make sure that you have internet for running this app.
2. Unzip this folder and go to 'client' folder.
3. On CMD, type 'npm install' and press 'Enter'. It will take some time to download all the packages for running this app.
4. Now type 'npm start' on CMD and press 'Enter'. It will launch this app to your browser.
5. Now you can see the app on your Browser.